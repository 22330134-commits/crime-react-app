import React, { useState } from 'react';
import '../style/crime.css';
import avatarImg from "../assets/officer.jpg";
const Home = () => {
  const [report, setReport] = useState({ officerName: '', notes: '', status: 'Pending' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Replace with your actual POST request to your DB
    console.log("Sending to Database:", report);
    alert("Report Added!");
    setReport({ officerName: '', notes: '', status: 'Pending' });
  };

  return (
     <div className="crime-container">
      
      <section className="report-section ">
      <img src={avatarImg} alt="Officer photo" className="profile-avatar" />
      <h2>Create New Crime Report</h2>
      <form onSubmit={handleSubmit}>
        <input 
          placeholder="Officer Name" 
          value={report.officerName}
          onChange={(e) => setReport({...report, officerName: e.target.value})}
          required 
        /><br/>
        <textarea 
          placeholder="Notes" 
          value={report.notes}
          onChange={(e) => setReport({...report, notes: e.target.value})}
        /><br/>
        <button type="submit">Submit Report</button>
      </form>
      </section>
    </div>
  );
};

export default Home;